let num1 = prompt('Enter the number')
let num2 = prompt('Enter the number')
let num3 = prompt('Enter the number')
let result = (Number(num1) + Number(num2) + Number(num3))/3
alert(result)