let num1 = prompt('Enter the number')
let num2 = prompt('Enter the number')
let massage = 'are the numbers equal? \n'

if (num1 === num2){ alert( massage + 'true')}else{alert( massage + 'false')}