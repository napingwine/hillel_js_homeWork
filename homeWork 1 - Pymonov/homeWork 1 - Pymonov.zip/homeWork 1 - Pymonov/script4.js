let massage1 = prompt('Enter 1st part of your massage')
let massage2 = prompt('Enter 2nd part of your massage')
let massage3 = prompt('Enter 3th part of your massage')
alert('Your massage: \n' + massage1 + ' ' + massage2 + ' ' + massage3)