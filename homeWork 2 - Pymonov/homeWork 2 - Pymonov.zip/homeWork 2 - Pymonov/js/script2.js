let kilometers = prompt("Enter your distance in kilometers")
let feets = prompt("Enter your distance in feets")
alert(kilometers > (feets * 0.0003048) ? "distance in kilometers bigger then distance in feets" : "distance in feets bigger then distance in kilometers");