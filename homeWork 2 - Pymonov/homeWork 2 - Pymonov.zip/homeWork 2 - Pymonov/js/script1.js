let num1 = prompt("Enter your 1st number")
let num2 = prompt("Enter your 2nd number")

num1 > num2 ? alert("num1 bigger then num2") : alert("num2 bigger then num1");