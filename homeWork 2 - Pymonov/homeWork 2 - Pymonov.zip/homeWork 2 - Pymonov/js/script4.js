let number = prompt("Enter your number")
alert(number % 2 === 0 ? "number is even number" : "number is odd number");
alert(number%10)